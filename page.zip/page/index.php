<?php 
require_once($_SERVER["DOCUMENT_ROOT"].'/update-cost/config/include.php');
require_once(home_path().'controller/fn-users.php');

global $conn;
date_default_timezone_set("Asia/Bangkok");

// ตรวจสอบการ login
is_login();

// Current User
$current_user = current_user();
$dateNow = date("Y-m-d");
?>

<?php 
if ($current_user['user_role'] == 'admin' || $current_user['user_role'] == 'purchase') {
    
}
else {
    unset($_SESSION['auth_sc']);
    if(empty($_SESSION['auth_sc'])) {
        header("Location:".HOME_URI."?error=err03");
        exit;
    }
} 
?>

<?php require_once(home_path().'config/header/header-page.php'); ?>

<div class="pc-container">
    <div class="pcoded-content">
        <!-- breadcrumb start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Dashboard</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item">Dashboard</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb end -->

        <!-- Main Content start -->

        <div class="row">
            <div class="col-xl-12 col-md-12">
                <div class="row">
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="card prod-p-card background-pattern-white">
                            <div class="card-body">
                                <div class="row align-items-center m-b-0">
                                    <div class="col">
                                        <h6 class="m-b-5">งานบริการทั้งหมด</h6>
                                        <h2 class="m-b-0 text-primary">10</h2>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-wrench text-primary"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="row text-center">
                                    <div class="col border-right">
                                        <h4 class="m-0">5</h4>
                                        <span class="text-md">กำลังดำเนินการ</span>
                                    </div>
                                    <div class="col border-right">
                                        <h4 class="m-0">2</h4>
                                        <span class="text-md">ดำเนินการเรียบร้อย</span>
                                    </div>
                                    <div class="col">
                                        <h4 class="m-0 ">3</h4>
                                        <span class="text-md">ดำเนินการยังไม่เรียบร้อย</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content end -->

    </div>
</div>

<div id="service_detail_modal"></div>

<?php require_once(home_path().'config/footer/footer.php'); ?>


<script type="text/javascript">
$(document).ready(function(){
    $('.prod-p-card').matchHeight();
});
</script>


