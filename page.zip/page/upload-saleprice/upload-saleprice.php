<?php
require_once($_SERVER["DOCUMENT_ROOT"].'/update-cost/config/include.php');
require_once($_SERVER["DOCUMENT_ROOT"].'/update-cost/config/connect.php');

if (isset($_POST['submit']) && isset($_FILES['file'])) {
    $dropdownValue = isset($_POST['database']) ? $_POST['database'] : '';
    $file = $_FILES['file'];

    // เชื่อมต่อฐานข้อมูลตาม dropdownValue
    switch ($dropdownValue) {
        case 'SCA':
            $conn = $GLOBAL['conn_sca'];
            break;
        case 'SCA10':
            $conn = $GLOBAL['conn_sca10'];
            break;
        case 'SCO':
            $conn = $GLOBAL['conn_sco'];
            break;
        case 'SCORP':
            $conn = $GLOBAL['conn_scorp'];
            break;
        case 'WECHILL':
            $conn = $GLOBAL['conn_wechill'];
            break;
        case 'Test':
            $conn = $GLOBAL['conn_test'];
            break;
        default:
            $conn = null;
            break;
    }

    if ($conn === null) {
        echo '<script>alert("Invalid database connection."); window.location.href="saleprice.php";</script>';
        exit;
    }

    $fileUploaded = false;

    // ตรวจสอบการอัปโหลดไฟล์
    if ($file['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $file['tmp_name'];
        $fileName = $file['name'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        // ตรวจสอบประเภทไฟล์
        if ($fileExtension === 'xlsx' || $fileExtension === 'xls') {
            require_once($_SERVER["DOCUMENT_ROOT"].'/update-cost/assets/PHPExcel/PHPExcel.php');
            require_once($_SERVER["DOCUMENT_ROOT"].'/update-cost/assets/PHPExcel/PHPExcel/IOFactory.php');

            // โหลดไฟล์ Excel ที่อัปโหลด
            $objPHPExcel = PHPExcel_IOFactory::load($fileTmpPath);
            $worksheet = $objPHPExcel->getActiveSheet();
            $highestRow = $worksheet->getHighestRow();
            
            $updateSuccess = true;

            for ($row = 2; $row <= $highestRow; $row++) {
                $goodid = $worksheet->getCell('A'.$row)->getValue();
                $goodcode = $worksheet->getCell('B'.$row)->getValue();
                $StandardSalePrce = $worksheet->getCell('G'.$row)->getValue();
                
                $sqlCheck = "SELECT Goodcode FROM EMGood WHERE Goodid = ?";
                $stmtCheck = sqlsrv_query($conn, $sqlCheck, [$goodid]);
                
                if ($stmtCheck === false) {
                    $updateSuccess = false;
                    break;
                }

                $rowCheck = sqlsrv_fetch_array($stmtCheck, SQLSRV_FETCH_ASSOC);
                
                if ($rowCheck && $rowCheck['Goodcode'] === $goodcode) {
                    $sqlUpdate = "UPDATE EMGood SET StandardSalePrce = ? WHERE Goodid = ?";
                    $paramsUpdate = [$StandardSalePrce, $goodid];
                    $stmtUpdate = sqlsrv_query($conn, $sqlUpdate, $paramsUpdate);
                    
                    if ($stmtUpdate === false) {
                        $updateSuccess = false;
                        break;
                    }
                } else {
                    $updateSuccess = false;
                    break;
                }
            }

            // ถ้าการอัปเดตฐานข้อมูลสำเร็จ
            if ($updateSuccess) {
                // บันทึกไฟล์ลงในโฟลเดอร์
                $uploadDir = $_SERVER["DOCUMENT_ROOT"] . '/update-cost/file-upload/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                $newFileName = time() . '_' . basename($fileName);
                $uploadFilePath = $uploadDir . $newFileName;

                if (move_uploaded_file($fileTmpPath, $uploadFilePath)) {
                    echo '<script>alert("File update successfully & uploaded to: ' . $uploadFilePath . '"); window.location.href="saleprice.php";</script>';
                } else {
                    echo '<script>alert("Failed to move uploaded file."); window.location.href="saleprice.php";</script>';
                }
            } else {
                echo '<script>alert("Failed to update database. File not saved."); window.location.href="saleprice.php";</script>';
            }
        } else {
            echo '<script>alert("Invalid file type. Please upload an Excel file."); window.location.href="saleprice.php";</script>';
        }
    } else {
        echo '<script>alert("File upload error. Please try again."); window.location.href="saleprice.php";</script>';
    }
} else {
    echo '<script>alert("No file uploaded or submit button not clicked."); window.location.href="saleprice.php";</script>';
}
?>
